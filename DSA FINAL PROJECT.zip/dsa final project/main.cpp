#include <iostream>
#include <string>
#include <chrono>
#include <iomanip>
#include <bits/stdc++.h> 

using namespace std;
using namespace chrono;
void mainMenu();
void displayInventory();
struct Product
{
    int id;
    string name;
    int quantity;
    float price;
    int daysToExpiry;
    Product(int i,string n,int q,float p,int de)
    {
    	id=i;
    	name=n;
    	quantity=q;
    	price=p;
    	daysToExpiry=de;
	}
	Product (){}
	
};

struct Node
{
    Product data;
    Node *next;

    Node(Product p)
    {
        data = p;
        next = NULL;
    }
};

struct TreeNode
{
    Product data;
    TreeNode *left;
    TreeNode *right;

    TreeNode(Product p)
    {
        data = p;
        left = NULL;
        right = NULL;
    }
};

class Min_heap
{
    Product arr[100];
    int size;

    void heapify_down(int i)
    {
        int smallest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if(left < size && arr[left].daysToExpiry < arr[smallest].daysToExpiry)
        {
            smallest = left;
        }

        if(right < size && arr[right].daysToExpiry < arr[smallest].daysToExpiry)
        {
            smallest = right;
        }

        if(smallest != i)
        {
            Product temp = arr[i];
            arr[i] = arr[smallest];
            arr[smallest] = temp;
            heapify_down(smallest);
        }
    }

public:
    Min_heap()
    {
        size = 0;
    }

    void insert(Product p)
    {
        if(size == 100)
        {
            cout << "Heap is full." << endl;
            return;
        }

        int i = size;
        arr[i] = p;
        size++;

        while(i > 0)
        {
            int parent = (i - 1) / 2;

            if(arr[i].daysToExpiry < arr[parent].daysToExpiry)
            {
                Product temp = arr[i];
                arr[i] = arr[parent];
                arr[parent] = temp;
                i = parent;
            }
            else
            {
                break;
            }
        }
    }

    void deleteByID(int id)
    {
        int i;

        for(i = 0; i < size; i++)
        {
            if(arr[i].id == id)
            {
                break;
            }
        }

        if(i == size)
        {
            return;
        }

        arr[i] = arr[size - 1];
        size--;

        if(i < size && i > 0 && arr[i].daysToExpiry < arr[(i - 1) / 2].daysToExpiry)
        {
            while(i > 0)
            {
                int parent = (i - 1) / 2;

                if(arr[i].daysToExpiry < arr[parent].daysToExpiry)
                {
                    Product temp = arr[i];
                    arr[i] = arr[parent];
                    arr[parent] = temp;
                    i = parent;
                }
                else
                {
                    break;
                }
            }
        }
        else if(i < size)
        {
            heapify_down(i);
        }
    }

    bool isEmpty()
    {
        return size == 0;
    }

    void displaySoonestExpiry()
    {
        if(isEmpty())
        {
            cout << "Inventory is empty." << endl;
            return;
        }

        cout << "Soonest Expiring Product: " << arr[0].name
             << " (ID: " << arr[0].id << ", " << arr[0].daysToExpiry << " days left)" << endl;
    }
};

Node *insertNode(Node *&head, Product p)
{
    Node *newnode = new Node(p);

    if(head == NULL)
    {
        head = newnode;
        return NULL;
    }

    Node *temp = head;

    while(temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = newnode;
    return temp;
}

bool searchNodeById(Node *head, int target)
{
    Node *temp = head;

    while(temp != NULL)
    {
        if(temp->data.id == target)
        {
            return true;
        }

        temp = temp->next;
    }

    return false;
}

void deleteNodeById(Node *&head, int targetId)
{
    if(head == NULL)
    {
        return;
    }

    if(head->data.id == targetId)
    {
        Node *del = head;
        head = head->next;
        delete del;
        return;
    }

    Node *temp = head;

    while(temp->next != NULL && temp->next->data.id != targetId)
    {
        temp = temp->next;
    }

    if(temp->next == NULL)
    {
        return;
    }

    Node *curr = temp->next;
    temp->next = curr->next;
    delete curr;
}

void displayAllProducts(Node *head)
{
    if(head == NULL)
    {
        cout << "No products available in inventory." << endl;
        return;
    }

    cout << "\n" << string(72, '-') << endl;
    cout << left << setw(10) << "ID"
         << setw(22) << "Name"
         << setw(14) << "Quantity"
         << setw(14) << "Price"
         << setw(12) << "Expiry(Days)" << endl;
    cout << string(72, '-') << endl;

    Node *temp = head;

    while(temp != NULL)
    {
        cout << left << setw(10) << temp->data.id
             << setw(22) << temp->data.name
             << setw(14) << temp->data.quantity
             << "$" << setw(13) << fixed << setprecision(2) << temp->data.price
             << setw(12) << temp->data.daysToExpiry << endl;
        temp = temp->next;
    }

    cout << string(72, '-') << endl;
}

TreeNode* InsertTree(TreeNode *root, Product p)
{
    if(root == NULL)
    {
        return new TreeNode(p);
    }

    if(p.quantity < root->data.quantity)
    {
        root->left = InsertTree(root->left, p);
    }
    else if(p.quantity > root->data.quantity)
    {
        root->right = InsertTree(root->right, p);
    }
    else
    {
        cout << "Note: Duplicate quantity found! Product was not inserted into BST." << endl;
    }

    return root;
}

TreeNode* FindMinStock(TreeNode *root)
{
    if(root == NULL)
    {
        return NULL;
    }

    while(root->left != NULL)
    {
        root = root->left;
    }

    return root;
}

TreeNode* FindMaxStock(TreeNode *root)
{
    if(root == NULL)
    {
        return NULL;
    }

    while(root->right != NULL)
    {
        root = root->right;
    }

    return root;
}

int CountLowStock(TreeNode *root)
{
    if(root == NULL)
    {
        return 0;
    }

    int count = 0;

    if(root->data.quantity < 10)
    {
        count++;
    }

    return count + CountLowStock(root->left) + CountLowStock(root->right);
}

void inorderHelper(TreeNode *root)
{
    if(root == NULL)
    {
        return;
    }

    inorderHelper(root->left);

    cout << left << setw(10) << root->data.id
         << setw(22) << root->data.name
         << setw(14) << root->data.quantity
         << "$" << setw(13) << fixed << setprecision(2) << root->data.price << endl;

    inorderHelper(root->right);
}

void displayInorder(TreeNode *root)
{
    if(root == NULL)
    {
        cout << "BST is empty." << endl;
        return;
    }

    cout << "\n" << string(60, '-') << endl;
    cout << left << setw(10) << "ID"
         << setw(22) << "Name"
         << setw(14) << "Quantity"
         << setw(14) << "Price" << endl;
    cout << string(60, '-') << endl;

    inorderHelper(root);

    cout << string(60, '-') << endl;
}

int CountTotalProducts(TreeNode *root)
{
    if(root == NULL)
    {
        return 0;
    }

    return 1 + CountTotalProducts(root->left) + CountTotalProducts(root->right);
}

float TotalPrice(TreeNode *root)
{
    if(root == NULL)
    {
        return 0;
    }

    return root->data.price + TotalPrice(root->left) + TotalPrice(root->right);
}

float average(TreeNode *root)
{
    int total = CountTotalProducts(root);

    if(total == 0)
    {
        return 0;
    }

    return TotalPrice(root) / total;
}

TreeNode* searchProductByQuantity(TreeNode *root, int quan)
{
    if(root == NULL || root->data.quantity == quan)
    {
        return root;
    }

    if(quan < root->data.quantity)
    {
        return searchProductByQuantity(root->left, quan);
    }

    return searchProductByQuantity(root->right, quan);
}

TreeNode* DeleteProductByID(TreeNode *root, int targetID)
{
    if(root == NULL)
    {
        return NULL;
    }

    if(root->data.id == targetID)
    {
        if(root->left == NULL && root->right == NULL)
        {
            delete root;
            return NULL;
        }
        else if(root->left == NULL)
        {
            TreeNode *temp = root->right;
            delete root;
            return temp;
        }
        else if(root->right == NULL)
        {
            TreeNode *temp = root->left;
            delete root;
            return temp;
        }
        else
        {
            TreeNode *successor = root->right;

            while(successor->left != NULL)
            {
                successor = successor->left;
            }

            root->data = successor->data;
            root->right = DeleteProductByID(root->right, successor->data.id);
        }
    }
    else
    {
        root->left = DeleteProductByID(root->left, targetID);

        if(root->data.id != targetID)
        {
            root->right = DeleteProductByID(root->right, targetID);
        }
    }

    return root;
}

int TotalQuantity(TreeNode *root)
{
    if(root == NULL)
    {
        return 0;
    }

    return root->data.quantity + TotalQuantity(root->left) + TotalQuantity(root->right);
}

void LowStockHelper(TreeNode *root, float avg)
{
    if(root == NULL)
    {
        return;
    }

    if(root->data.quantity < avg)
    {
        cout << " - " << left << setw(20) << root->data.name
             << " | Quantity: " << root->data.quantity << endl;
    }

    LowStockHelper(root->left, avg);
    LowStockHelper(root->right, avg);
}

void LowStockAnalysis(TreeNode *root)
{
    if(root == NULL)
    {
        cout << "No products available for analysis." << endl;
        return;
    }

    int totalProducts = CountTotalProducts(root);

    if(totalProducts == 0)
    {
        return;
    }

    float avg = static_cast<float>(TotalQuantity(root)) / totalProducts;
    cout << "Average Stock Quantity: " << fixed << setprecision(2) << avg << endl;
    cout << "Products Below Average Stock:" << endl;
    LowStockHelper(root, avg);
}

void add_product(Node *&head, TreeNode *&root, Min_heap &expiryHeap, Product p)
{
    if(searchNodeById(head, p.id))
    {
        cout << "Error: Product with ID " << p.id << " already exists." << endl;
        return;
    }

    insertNode(head, p);
    root = InsertTree(root, p);
    expiryHeap.insert(p);
    cout << "Product added successfully!" << endl;
}

void DeleteProduct(Node *&head, TreeNode *&root, Min_heap &expiryHeap, int id)
{
    if(!searchNodeById(head, id))
    {
        cout << "Product not found!" << endl;
        return;
    }

    deleteNodeById(head, id);
    root = DeleteProductByID(root, id);
    expiryHeap.deleteByID(id);
    cout << "Product deleted from inventory!" << endl;
}

void bubble_sort(Product arr[], int n)
{
    for(int i = 0; i < n - 1; i++)
    {
        for(int j = 0; j < n - i - 1; j++)
        {
            if(arr[j].price > arr[j + 1].price)
            {
                Product temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void merge(Product arr[], int low, int mid, int high)
{
    int i = low;
    int j = mid + 1;
    int k = 0;
    Product temp[100];

    while(i <= mid && j <= high)
    {
        if(arr[i].price <= arr[j].price)
        {
            temp[k] = arr[i];
            i++;
        }
        else
        {
            temp[k] = arr[j];
            j++;
        }

        k++;
    }

    while(i <= mid)
    {
        temp[k] = arr[i];
        i++;
        k++;
    }

    while(j <= high)
    {
        temp[k] = arr[j];
        j++;
        k++;
    }

    for(i = low, k = 0; i <= high; i++, k++)
    {
        arr[i] = temp[k];
    }
}

void mergeSort(Product arr[], int low, int high)
{
    if(low < high)
    {
        int mid = (low + high) / 2;

        mergeSort(arr, low, mid);
        mergeSort(arr, mid + 1, high);
        merge(arr, low, mid, high);
    }
}

int partition(Product arr[], int low, int high)
{
    Product pivot = arr[high];
    int i = low - 1;

    for(int j = low; j < high; j++)
    {
        if(arr[j].price < pivot.price)
        {
            i++;

            Product temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }

    Product temp = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = temp;

    return i + 1;
}

void quickSort(Product arr[], int low, int high)
{
    if(low < high)
    {
        int pivot = partition(arr, low, high);

        quickSort(arr, low, pivot - 1);
        quickSort(arr, pivot + 1, high);
    }
}

void findExecution_time(Product arr[], int n)
{
    if(n <= 0 || n > 100)
    {
        cout << "Inventory must have between 1 and 100 products to run sorting benchmark." << endl;
        return;
    }

    Product bubbleArr[100];
    Product mergeArr[100];
    Product quickArr[100];

    for(int i = 0; i < n; i++)
    {
        bubbleArr[i] = arr[i];
        mergeArr[i] = arr[i];
        quickArr[i] = arr[i];
    }

    auto start1 = high_resolution_clock::now();
    bubble_sort(bubbleArr, n);
    auto end1 = high_resolution_clock::now();
    auto duration1 = duration_cast<microseconds>(end1 - start1);

    auto start2 = high_resolution_clock::now();
    mergeSort(mergeArr, 0, n - 1);
    auto end2 = high_resolution_clock::now();
    auto duration2 = duration_cast<microseconds>(end2 - start2);

    auto start3 = high_resolution_clock::now();
    quickSort(quickArr, 0, n - 1);
    auto end3 = high_resolution_clock::now();
    auto duration3 = duration_cast<microseconds>(end3 - start3);

    std::setprecision(5);
       // std::cout << std::setprecision(2) << std::fixed;

    cout << "\n" << string(45, '-') << endl;
    cout << left << setw(25) << "Sorting Algorithm" << setw(20) << "Execution Time" << endl;
    cout << string(45, '-') << endl;
    cout << left << setw(25) << "Bubble Sort" <<std::fixed<<(duration1.count())<< " microseconds" << endl;
    cout << left << setw(25) << "Merge Sort" <<std::fixed<< (duration2.count())<< " microseconds" << endl;
    cout << left << setw(25) << "Quick Sort" <<std::fixed<< (duration3.count())<< " microseconds" << endl;
    cout << string(45, '-') << endl;

    cout << "\nProducts Sorted by Price (Ascending):" << endl;
    cout << string(60, '-') << endl;
    cout << left << setw(10) << "ID"
         << setw(22) << "Name"
         << setw(14) << "Price"
         << setw(14) << "Quantity" << endl;
    cout << string(60, '-') << endl;

    for(int i = 0; i < n; i++)
    {
        cout << left << setw(10) << quickArr[i].id
             << setw(22) << quickArr[i].name
             << "$" << setw(13) << fixed << setprecision(2) << quickArr[i].price
             << setw(14) << quickArr[i].quantity << endl;
    }

    cout << string(60, '-') << endl;
}

void copyListToArray(Node *head, Product arr[], int &n)
{
    n = 0;
    Node *temp = head;

    while(temp != NULL && n < 100)
    {
        arr[n] = temp->data;
        n++;
        temp = temp->next;
    }
}

void deleteList(Node *&head)
{
    while(head != NULL)
    {
        Node *temp = head;
        head = head->next;
        delete temp;
    }
}

void deleteTree(TreeNode *root)
{
    if(root == NULL)
    {
        return;
    }

    deleteTree(root->left);
    deleteTree(root->right);
    delete root;
}

void displayMenu()
{
    cout << "\n==================================================" << endl;
    cout << "           INVENTORY MANAGEMENT SYSTEM            " << endl;
    cout << "==================================================" << endl;
    cout << "  1. Add New Product" << endl;
    cout << "  2. Delete Product by ID" << endl;
    cout << "  3. Display All Products (Linked List)" << endl;
    cout << "  4. Display Products Sorted by Quantity (BST)" << endl;
    cout << "  5. Search Product by Quantity (BST)" << endl;
    cout << "  6. Inventory & Stock Analytics" << endl;
    cout << "  7. Check Soonest Expiring Product (Min-Heap)" << endl;
    cout << "  8. Sort Products by Price & Compare Algorithms" << endl;
    cout << "  0. Exit" << endl;
    cout << "==================================================" << endl;
    cout << "Enter your choice: ";
}

int time_start()
{
	
}

int main()
{
/*	time_t start, end;
	time (&start);
    ios_base::sync_with_stdio(false); 

	for (int i=0; i<1000; i++);
	time (&end);
	
	    double time_taken = double(end - start); 

	
	cout << "Time taken by program is : " << fixed 
        << time_taken << setprecision(5); 
    cout << " sec " << endl;
*/	
		
	//  std::cout.precision(5);
	
	//cout<<std::fixed<<4.56;
//	getchar();
	
    Node *head = NULL;
    TreeNode *root = NULL;
    Min_heap expiryHeap;

    Product p1  = Product(8, "teapack", 9, 90.7, 3);
    Product p2  = Product(9, "milk", 11, 99.7, 7);
    Product p3  = Product(10, "shampoo", 3, 70.7, 9);
    Product p4  = Product(2, "powder", 7, 30.7, 7);
    Product p5  = Product(7, "lotion", 45, 70.7, 7);
    Product p6  = Product(23, "soda", 2, 70.4, 12);
    Product p7  = Product(11, "biscuits", 15, 45.5, 5);
    Product p8  = Product(12, "bread", 8, 60.5, 4);
    Product p9  = Product(13, "butter", 6, 120.7, 8);
    Product p10 = Product(14, "juice", 20, 85.5, 6);
    Product p11 = Product(15, "soap", 12, 35.5, 9);
    Product p12 = Product(16, "rice", 25, 150.7, 2);
    Product p13 = Product(17, "sugar", 30, 80.5, 7);
    Product p14 = Product(18, "coffee", 5, 250.7, 10);
    Product p15 = Product(19, "eggs", 18, 110.5, 3);
    Product p16 = Product(20, "flour", 22, 95.5, 6);
    Product p17 = Product(21, "chips", 14, 40.7, 5);
    Product p18 = Product(22, "shampoo", 10, 180.5, 8);

    Product products[] = {
        p1, p2, p3, p4, p5, p6,
        p7, p8, p9, p10, p11, p12,
        p13, p14, p15, p16, p17, p18
    };

    int total = 18;

    for(int i = 0; i < total; i++)
    {
        insertNode(head, products[i]);

        root = InsertTree(root, products[i]);

        expiryHeap.insert(products[i]);
    }

    cout << "\nInitial Inventory Loaded Successfully!" << endl;

    displayAllProducts(head);

    int choice;

    do
    {
        displayMenu();
        cin >> choice;

        switch(choice)
        {
            case 1:
            {
                Product p;
                cout << "\n--- Add New Product ---" << endl;
                cout << "Enter Product ID: ";
                cin >> p.id;
                cout << "Enter Name (one word): ";
                cin >> p.name;
                cout << "Enter Quantity (unique for BST): ";
                cin >> p.quantity;
                cout << "Enter Price: ";
                cin >> p.price;
                cout << "Enter Days to Expiry: ";
                cin >> p.daysToExpiry;

                add_product(head, root, expiryHeap, p);
                break;
            }

            case 2:
            {
                int id;
                cout << "\n--- Delete Product ---" << endl;
                cout << "Enter Product ID to delete: ";
                cin >> id;
                DeleteProduct(head, root, expiryHeap, id);
                break;
            }

            case 3:
            {
                cout << "\n--- All Inventory Products ---" << endl;
                displayAllProducts(head);
                break;
            }

            case 4:
            {
                cout << "\n--- Products Sorted by Quantity (BST Inorder) ---" << endl;
                displayInorder(root);
                break;
            }

            case 5:
            {
                int quan;
                cout << "\n--- Search Product by Quantity ---" << endl;
                cout << "Enter Quantity to search: ";
                cin >> quan;

                TreeNode *found = searchProductByQuantity(root, quan);

                if(found != NULL)
                {
                    cout << "Product Found -> ID: " << found->data.id
                         << " | Name: " << found->data.name
                         << " | Price: $" << fixed << setprecision(2) << found->data.price
                         << " | Expiry: " << found->data.daysToExpiry << " days" << endl;
                }
                else
                {
                    cout << "No product found with quantity " << quan << "." << endl;
                }
                break;
            }

            case 6:
            {
                cout << "\n--- Inventory & Stock Analytics ---" << endl;
                if(root == NULL)
                {
                    cout << "Inventory is empty." << endl;
                    break;
                }

                TreeNode *minProduct = FindMinStock(root);
                TreeNode *maxProduct = FindMaxStock(root);

                cout << "Minimum Stock Product     : " << minProduct->data.name
                     << " (" << minProduct->data.quantity << " units)" << endl;
                cout << "Maximum Stock Product     : " << maxProduct->data.name
                     << " (" << maxProduct->data.quantity << " units)" << endl;
                cout << "Average Product Price     : $" << fixed << setprecision(2) << average(root) << endl;
                cout << "Low Stock Items (< 10)    : " << CountLowStock(root) << endl;
                cout << "\n--- Low Stock Analysis ---" << endl;
                LowStockAnalysis(root);
                break;
            }

            case 7:
            {
                cout << "\n--- Expiry Priority Alert ---" << endl;
                expiryHeap.displaySoonestExpiry();
                break;
            }

            case 8:
            {
                cout << "\n--- Sorting & Execution Time Comparison ---" << endl;
                Product products[100];
                int count;
                copyListToArray(head, products, count);
                findExecution_time(products, count);
                break;
            }

            case 0:
            {
                cout << "\nExiting system and freeing memory. Goodbye!" << endl;
                break;
            }

            default:
            {
                cout << "\nInvalid choice! Please select a valid option (0-8)." << endl;
                break;
            }
        }

    } while(choice != 0);

    deleteList(head);
    deleteTree(root);
    return 0;
}
